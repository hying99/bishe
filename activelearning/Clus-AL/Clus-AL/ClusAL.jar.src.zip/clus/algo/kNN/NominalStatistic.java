/*    */ package clus.algo.kNN;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NominalStatistic
/*    */   extends AttributeStatistic
/*    */ {
/*    */   private int $mean;
/*    */   
/*    */   public int mean() {
/* 37 */     return this.$mean;
/*    */   }
/*    */   public void setMean(int m) {
/* 40 */     this.$mean = m;
/*    */   }
/*    */ }


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL.jar!\clus\algo\kNN\NominalStatistic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */