package clus.data.type;

import clus.util.ClusException;
import java.io.IOException;

public interface ClusSchemaInitializer {
  void initSchema(ClusSchema paramClusSchema) throws ClusException, IOException;
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL.jar!\clus\data\type\ClusSchemaInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */