package clus.ext.hierarchical;

public interface HierBasicDistance {
  double getVirtualRootWeight();
  
  double calcDistance(ClassTerm paramClassTerm1, ClassTerm paramClassTerm2);
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL.jar!\clus\ext\hierarchical\HierBasicDistance.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */