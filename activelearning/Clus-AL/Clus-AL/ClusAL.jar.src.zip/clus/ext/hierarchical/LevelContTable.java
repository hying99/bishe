package clus.ext.hierarchical;

public class LevelContTable {}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL.jar!\clus\ext\hierarchical\LevelContTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */