/*    */ package clus.gui;
/*    */ 
/*    */ import clus.ext.hierarchical.ClassTerm;
/*    */ import javax.swing.tree.DefaultMutableTreeNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JTHierTreeNode
/*    */   extends DefaultMutableTreeNode
/*    */ {
/*    */   public static final long serialVersionUID = 1L;
/*    */   
/*    */   public JTHierTreeNode(ClassTerm val) {
/* 35 */     super(val);
/*    */   }
/*    */   
/*    */   public JTHierTreeNode() {}
/*    */ }


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL.jar!\clus\gui\JTHierTreeNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */