package clus.gui.statvis;

import clus.statistic.ClusStatistic;
import jeans.graph.swing.drawable.Drawable;

public interface ClusStatVisualizer {
  Drawable createInstance(ClusStatistic paramClusStatistic);
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL.jar!\clus\gui\statvis\ClusStatVisualizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */