/*    */ package clus.model.pmml.tildepmml;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataField
/*    */ {
/*    */   protected String name;
/*    */   protected String opType;
/*    */   
/*    */   public String getName() {
/* 36 */     return this.name;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getOpType() {
/* 42 */     return this.opType;
/*    */   }
/*    */   
/*    */   public void print() {}
/*    */ }


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL.jar!\clus\model\pmml\tildepmml\DataField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */