/*    */ package clus.pruning;
/*    */ 
/*    */ import clus.error.ClusError;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ErrorVisitor
/*    */ {
/*    */   public ClusError testerr;
/*    */   
/*    */   public ErrorVisitor createInstance() {
/* 35 */     return new ErrorVisitor();
/*    */   }
/*    */ }


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL.jar!\clus\pruning\ErrorVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */