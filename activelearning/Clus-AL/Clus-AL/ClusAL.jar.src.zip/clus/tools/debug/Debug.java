package clus.tools.debug;

public class Debug {
  public static final int debug = 0;
  
  public static final boolean HIER_DEBUG = false;
  
  public static final boolean HIER_JANS_PAPER = false;
  
  public static final boolean HEURISTIC_DEBUG = false;
  
  public static final boolean MAKE_ID_FILES = false;
  
  public static final boolean MAKE_PRED_FILES = false;
  
  public static final boolean HIER_ERROR_DEBUG = true;
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL.jar!\clus\tools\debug\Debug.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */