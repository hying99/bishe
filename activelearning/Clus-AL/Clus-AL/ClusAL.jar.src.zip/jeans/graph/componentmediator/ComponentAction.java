package jeans.graph.componentmediator;

public interface ComponentAction {
  void execute(ComponentMediator paramComponentMediator);
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL.jar!\jeans\graph\componentmediator\ComponentAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */