package jeans.graph.plot;

import java.awt.Color;

public interface MDistrInfo {
  int getNbBins();
  
  float getBinCount(int paramInt);
  
  Color getBinColor(int paramInt);
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL.jar!\jeans\graph\plot\MDistrInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */