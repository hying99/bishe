package org.apache.commons.math.analysis;

public interface DifferentiableUnivariateRealFunction extends UnivariateRealFunction {
  UnivariateRealFunction derivative();
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL.jar!\jars\commons-math-1.0.jar!\org\apache\commons\math\analysis\DifferentiableUnivariateRealFunction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */