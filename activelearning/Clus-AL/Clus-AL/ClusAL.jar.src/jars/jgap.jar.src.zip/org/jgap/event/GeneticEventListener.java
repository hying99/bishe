package org.jgap.event;

public interface GeneticEventListener {
  public static final String CVS_REVISION = "$Revision: 1.5 $";
  
  void geneticEventFired(GeneticEvent paramGeneticEvent);
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL.jar!\jars\jgap.jar!\org\jgap\event\GeneticEventListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */