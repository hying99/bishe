package org.jgap.gp;

import org.jgap.GeneticOperator;

public interface IGPGeneticOperator extends GeneticOperator {
  public static final String CVS_REVISION = "$Revision: 1.2 $";
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL.jar!\jars\jgap.jar!\org\jgap\gp\IGPGeneticOperator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */