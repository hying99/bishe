/*    */ package org.jgap.supergenes;
/*    */ 
/*    */ import org.jgap.Configuration;
/*    */ import org.jgap.Gene;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TestValidator
/*    */   extends Validator
/*    */ {
/*    */   public TestValidator(Configuration a_conf) {
/* 54 */     super(a_conf);
/*    */   }
/*    */   
/*    */   public boolean isValid(Gene[] a_gene, Supergene a_supergene) {
/* 58 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL.jar!\jars\jgap.jar!\org\jgap\supergenes\TestValidator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */