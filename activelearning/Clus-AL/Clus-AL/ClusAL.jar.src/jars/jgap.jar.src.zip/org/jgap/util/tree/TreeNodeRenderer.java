package org.jgap.util.tree;

import java.awt.Color;

public interface TreeNodeRenderer {
  public static final String CVS_REVISION = "$Revision: 1.1 $";
  
  Color getNodeColor(Object paramObject, int paramInt);
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL.jar!\jars\jgap.jar!\org\jga\\util\tree\TreeNodeRenderer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */