package weka.core;

public class UnsupportedClassTypeException extends WekaException {
  public UnsupportedClassTypeException() {}
  
  public UnsupportedClassTypeException(String paramString) {
    super(paramString);
  }
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL.jar!\jars\weka.jar!\weka\core\UnsupportedClassTypeException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */