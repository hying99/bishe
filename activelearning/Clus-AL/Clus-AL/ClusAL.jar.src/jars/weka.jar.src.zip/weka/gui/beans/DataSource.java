package weka.gui.beans;

public interface DataSource {
  void addDataSourceListener(DataSourceListener paramDataSourceListener);
  
  void removeDataSourceListener(DataSourceListener paramDataSourceListener);
  
  void addInstanceListener(InstanceListener paramInstanceListener);
  
  void removeInstanceListener(InstanceListener paramInstanceListener);
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL.jar!\jars\weka.jar!\weka\gui\beans\DataSource.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */