package org.apache.commons.math.distribution;

public interface GammaDistribution extends ContinuousDistribution {
  void setAlpha(double paramDouble);
  
  double getAlpha();
  
  void setBeta(double paramDouble);
  
  double getBeta();
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL\!\jars\commons-math-1.0.jar!\org\apache\commons\math\distribution\GammaDistribution.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */