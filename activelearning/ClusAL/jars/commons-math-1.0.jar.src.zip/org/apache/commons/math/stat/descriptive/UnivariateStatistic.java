package org.apache.commons.math.stat.descriptive;

public interface UnivariateStatistic {
  double evaluate(double[] paramArrayOfdouble);
  
  double evaluate(double[] paramArrayOfdouble, int paramInt1, int paramInt2);
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL\!\jars\commons-math-1.0.jar!\org\apache\commons\math\stat\descriptive\UnivariateStatistic.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */