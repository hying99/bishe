package weka.core;

public interface Summarizable {
  String toSummaryString();
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL\!\jars\weka.jar!\weka\core\Summarizable.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */