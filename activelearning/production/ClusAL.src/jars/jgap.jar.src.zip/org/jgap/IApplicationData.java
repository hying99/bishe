package org.jgap;

public interface IApplicationData extends Comparable, Cloneable {
  public static final String CVS_REVISION = "$Revision: 1.4 $";
  
  Object clone() throws CloneNotSupportedException;
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL\!\jars\jgap.jar!\org\jgap\IApplicationData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */