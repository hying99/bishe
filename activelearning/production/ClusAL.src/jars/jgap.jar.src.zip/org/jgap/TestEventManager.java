package org.jgap;

import org.jgap.event.EventManager;

class TestEventManager extends EventManager {}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL\!\jars\jgap.jar!\org\jgap\TestEventManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */