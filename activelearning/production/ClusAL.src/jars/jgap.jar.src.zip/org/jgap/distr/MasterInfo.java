package org.jgap.distr;

public class MasterInfo {
  private static final String CVS_REVISION = "$Revision: 1.2 $";
  
  public String m_IPAddress;
  
  public String m_name;
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL\!\jars\jgap.jar!\org\jgap\distr\MasterInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */