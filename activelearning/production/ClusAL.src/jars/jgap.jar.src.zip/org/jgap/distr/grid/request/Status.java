package org.jgap.distr.grid.request;

import java.io.Serializable;

public class Status implements Serializable {
  public int code;
  
  public String description;
  
  public byte[] buffer;
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL\!\jars\jgap.jar!\org\jgap\distr\grid\request\Status.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */