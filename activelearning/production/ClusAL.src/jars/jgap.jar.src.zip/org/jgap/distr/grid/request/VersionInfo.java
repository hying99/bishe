package org.jgap.distr.grid.request;

import java.io.Serializable;

public class VersionInfo implements Serializable {
  public String currentVersion;
  
  public String filenameOfLib;
  
  public String libName;
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL\!\jars\jgap.jar!\org\jgap\distr\grid\request\VersionInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */