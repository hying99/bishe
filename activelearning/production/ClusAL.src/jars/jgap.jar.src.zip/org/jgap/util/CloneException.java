/*    */ package org.jgap.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CloneException
/*    */   extends RuntimeException
/*    */ {
/*    */   static final String CVS_REVISION = "$Revision: 1.1 $";
/*    */   
/*    */   public CloneException() {}
/*    */   
/*    */   public CloneException(Throwable a_throwable) {
/* 20 */     super(a_throwable);
/*    */   }
/*    */   
/*    */   public CloneException(String a_message) {
/* 24 */     super(a_message);
/*    */   }
/*    */ }


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL\!\jars\jgap.jar!\org\jga\\util\CloneException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */