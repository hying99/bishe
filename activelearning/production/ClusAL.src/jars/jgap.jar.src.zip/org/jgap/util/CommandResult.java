package org.jgap.util;

public class CommandResult {
  private static final String CVS_REVISION = "$Revision: 1.3 $";
}


/* Location:              C:\Users\1231\Desktop\dataprocessing\activelearning\Clus-AL\Clus-AL\ClusAL\!\jars\jgap.jar!\org\jga\\util\CommandResult.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */